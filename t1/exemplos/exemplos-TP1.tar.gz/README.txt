Exemplos para o TP1

Os nomes dos exemplos tem as respostas. Os nomes são formados por um
número (índice do exemplo), a palavra "custo" seguida de um valor (custo
ótimo do exemplo), uma sequência de números separados por hífen (o
caminho instalado ótimo). Um dos exemplos não tem solução viável
(4inviavel.in) e seu nome é diferente or isso.

Os arquivos são:
1custo50-1-2-3.in 
2custo50-1-2-4-3-5-6.in
3custo18-1-6-4-2.in
4inviavel.in
