for (( c=20; c<=35; c++ ))
do  
    ./a.out < exemplos/$c.in 2> $c.out
done